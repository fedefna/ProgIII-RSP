<?php

use App\Controllers\MascotaController;
use Slim\Routing\RouteCollectorProxy;
use App\Middlewares\JsonMiddleware;
use App\Middlewares\AuthMiddleware;
use App\Controllers\UsuarioController;
use App\Controllers\TurnoController;
use Slim\Factory\AppFactory;
use Config\Database;

require __DIR__ . '/../vendor/autoload.php';

$app = AppFactory::create();
$app->setBasePath('/ProgramacionIII/RSP/public');
$app->addBodyParsingMiddleware(); //Este se encarga de parsear los Json del Body Request. Si no, no podriamos enviar Json.
new Database;



$app->group('/usuarios', function (RouteCollectorProxy $group) {
    $group->post('/login[/]', UsuarioController::class . ":login");
})->add(new JsonMiddleware);

$app->group('/usuarios', function (RouteCollectorProxy $group) {
    $group->post('/registrar[/]', UsuarioController::class . ":addOne");
})->add(new JsonMiddleware);

$app->group('/mascotas', function (RouteCollectorProxy $group) {
    $group->get('[/]', MascotaController::class.":getAll");
    $group->post('/agregar[/]', MascotaController::class . ":addOne");
    
})->add(new AuthMiddleware('Admin'))->add(new JsonMiddleware);

$app->group('/turnos', function (RouteCollectorProxy $group) {
    $group->get('[/]', TurnoController::class.":getAll")->add(new AuthMiddleware('Admin'));
    $group->post('/registrar[/]', TurnoController::class . ":addOne")->add(new AuthMiddleware('Cliente'));
    $group->put('/marcar/{turno_id}[/]', TurnoController::class . ":marcarTurno")->add(new AuthMiddleware('Admin'));
})->add(new JsonMiddleware);

$app->group('/facturas', function (RouteCollectorProxy $group) {
    $group->get('[/]', TurnoController::class . ":buscarTurnosAtendidos")->add(new AuthMiddleware('Cliente'));
})->add(new JsonMiddleware);


$app->addBodyParsingMiddleware(); 
$app->run();
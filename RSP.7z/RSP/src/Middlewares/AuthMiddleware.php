<?php

namespace App\Middlewares;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Psr7\Response;
use \Firebase\JWT\JWT as JWT;
use stdClass;

define('KEY2', "tp_Comanda");

class AuthMiddleware
{
    /**
     * Example middleware invokable class
     *
     * @param  ServerRequest  $request PSR-7 request
     * @param  RequestHandler $handler PSR-15 request handler
     *
     * @return Response
     */

    private $_typeuser;

    public function __construct(string $role1, string $role2 = '', string $role3='', string $role4='', string $role5='')
    {
        $this->roles = array();
        array_push($this->roles, $role1,$role2,$role3,$role4,$role5);
    }

    public function __invoke(Request $request, RequestHandler $handler): Response
    {

        $headers = getallheaders();
       
        $token = $headers['Token'];

        $res = new stdClass;
        $resp = new Response();

        try {
           
            $jwt = JWT::decode($token, KEY2, array('HS256'));
            
            if (in_array($jwt->tipo, $this->roles)) {
                
                $response = $handler->handle($request);
                $existingContent = (string) $response->getBody();
                
                $resp->getBody()->write($existingContent);
               
                return $resp;
            } else {
                $res->message = "Tipo de usuario Invalido";
                
                $resp->getBody()->write(json_encode($res));
            }
        } catch (\Throwable $th) {
            
            $res->message = $th->getMessage();
            $resp->getBody()->write(json_encode($res));
        } 
        return $resp;
    }
}

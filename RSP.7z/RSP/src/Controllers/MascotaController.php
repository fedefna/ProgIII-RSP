<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Mascota;
use Exception;
use \Firebase\JWT\JWT as JWT;
use stdClass;


class MascotaController
{

    public function getAll(Request $request, Response $response, $args)
    {
        $pedido = Mascota::get();

        $response->getBody()->write(json_encode($pedido));
        return $response;
    }

    public function getOne(Request $request, Response $response, $args)
    {
        $req = $request->getParsedBody();

        $mesa = Mascota::find($req['id']);
        $response->getBody()->write(json_encode($mesa));
        return $response;
    }


    public function addOne(Request $request, Response $response, $args)
    {
        $req = $request->getParsedBody();
        $mascota = new Mascota;
        $resp = new stdClass;

        try {
            if ($req['tipo'] != "Perro" && $req['tipo'] != "Gato" && $req['tipo'] != "Huron") throw new Exception('Tipo de mascota invalido.');

            $mascota->tipo = $req['tipo'];
            $mascota->precio = $req['precio'];
            $mascota->save();

            $resp = $mascota;
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(200);
        } catch (\Throwable $th) {
            $resp->message = $th->getMessage();
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(500);
        }
    }
/* 
    public function cambiarEstado(Request $request, Response $response, $args)
    {
        $headers = getallheaders();
        $token = $headers['Token'];
        $jwt = JWT::decode($token, KEY2, array('HS256'));

        $req = $request->getParsedBody();

        try {
            if ($req['estado'] != "Con cliente esperando pedido" && $req['estado'] != "Con clientes comiendo" && $req['estado'] != "Con clientes pagando" && $req['estado'] != "Cerrada") throw new Exception('Estado de mesa invalido.');

            $mesa = Mesa::where('codigo', $req['codigo'])->get();
            $resp = new stdClass;
            if ($mesa) {
                if ($req['estado'] == "Cerrada" && $jwt->especialidad == 'Mozo') {
                    throw new Exception('Su usuario no tiene permitido cerrar una mesa.');
                } else {
                    $mesa[0]->estado = $req['estado'];
                    $mesa[0]->save();
                    $resp = $mesa[0];
                }
            }

            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(200);

        } catch (\Throwable $th) {
            $resp->message = $th->getMessage();
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(500);
        }
    }

    public static function abrirMesa($codigo)
    {
        try {
            $mesa = Mesa::where('codigo', $codigo)->get();
            $resp=false;
            if ($mesa[0]->estado=="Cerrada") {
                $mesa[0]->estado="Con cliente esperando pedido";
                $resp=$mesa[0]->save();
            }
            return $resp;

        } catch (\Throwable $th) {
            throw new Exception('ID de mesa invalido.');
        }
    } */

}

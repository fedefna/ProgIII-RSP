<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Turno;
use App\Models\Usuario;
use App\Models\Mascota;
use \Firebase\JWT\JWT as JWT;
use Exception;
use stdClass;


define('KEY', "tp_Comanda");


class TurnoController
{

    public function getAll(Request $request, Response $response, $args)
    {
        $turnos = Turno::get();
        
        $resp = new stdClass;
        foreach ($turnos as $key => $value) {
            $user = Usuario::where('id', $value->cliente_id)->get();
            $tipoMascota = Mascota::where('tipo', $value->tipo)->get();

            $value->nombre_cliente=$user[0]->nombre;
            $value->precio=$tipoMascota[0]->precio;

        }
        $response->getBody()->write(json_encode($turnos));

        return $response;
    }

    public function getOne(Request $request, Response $response, $args)
    {
        $prod = Turno::find($args['id']);
        $response->getBody()->write(json_encode($prod));
        return $response;
    }


    public function addOne(Request $request, Response $response, $args)
    {
        $headers = getallheaders();
        $token = $headers['Token'];
        $jwt = JWT::decode($token, KEY2, array('HS256'));

        $req = $request->getParsedBody();
        $turno = new Turno;
        $resp = new stdClass;

        try {
            if ($req['tipo'] != "Perro" && $req['tipo'] != "Gato" && $req['tipo'] != "Huron") throw new Exception('Tipo de mascota invalido.');

            $turno->tipo = $req['tipo'];
            $turno->fecha = $req['fecha'];
            $turno->cliente_id = $jwt->id;
            $turno->atendido = false;

            $turno->save();

            $resp = $turno;
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(200);
        } catch (\Throwable $th) {
            $resp->status = 500;
            $resp->message = $th->getMessage();
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(500);
        }
    }

    public function marcarTurno(Request $request, Response $response, $args)
    {
        $resp = new stdClass;

        try {
            $turno = Turno::where('id', $args['turno_id'])->first();
            $turno->atendido = true;
            $turno->save();

            $resp = $turno;
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(200);
        } catch (\Throwable $th) {
            $resp->message = $th->getMessage();
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(500);
        }
    }
    
    public function buscarTurnosAtendidos(Request $request, Response $response, $args)
    {
        $resp = new stdClass;
        $headers = getallheaders();
        $token = $headers['Token'];
        $jwt = JWT::decode($token, KEY2, array('HS256'));

        try {
            $turnos = Turno::where('cliente_id', $jwt->id)
            ->where('atendido',true)->get();
            
            $resp = $turnos;
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(200);
        } catch (\Throwable $th) {
            $resp->message = $th->getMessage();
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(500);
        }
    }
}

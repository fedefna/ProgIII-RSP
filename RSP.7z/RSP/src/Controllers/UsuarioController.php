<?php

namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Usuario;
use Exception;
use \Firebase\JWT\JWT as JWT;
use stdClass;

define('KEY', "tp_Comanda");

class UsuarioController
{

    public function getAll(Request $request, Response $response, $args)
    {
        $pedido = Usuario::get();

        $response->getBody()->write(json_encode($pedido));
        return $response;
    }

    public function getOne(Request $request, Response $response, $args)
    {
        $req = $request->getParsedBody();

        $user = Usuario::where('nombre', $args['nombre'])->get();

        //$user = Usuario::find("Admin 1");
        $response->getBody()->write(json_encode($user));
        return $response;
    }


    public function addOne(Request $request, Response $response, $args)
    {
        $req = $request->getParsedBody();
        $user = new Usuario;
        //$pass = base64_encode($req['password']);
        $pass =$req['password'];
        $resp = new stdClass;

        try {
            if ($req['tipo'] != "Cliente" && $req['tipo'] != "Admin") throw new Exception('Tipo de user invalido.');

            if(strlen($req['password']) < 4) throw new Exception('Password demasiado corta');
            $user->nombre = $req['nombre'];
            $user->password = $pass;
            $user->email = $req['email'];
            $user->tipo = $req['tipo'];

            $user->save();
            $response->getBody()->write(json_encode($user));
            return $response->withStatus(200);
        } catch (\Throwable $th) {
            $resp->message = $th->getMessage();
            $response->getBody()->write(json_encode($resp));
            return $response->withStatus(500);
        }
    }


    public function login(Request $request, Response $response, $args)
    {
        $req = $request->getParsedBody();
        $usr = $this->userIsRegistered($req['nombre'], $req['password']);
        $resp = new stdClass;

        try {

            if ($usr) {

                $payload = array(
                    "iat" => 1356999524,
                    "nbf" => 1357000000,
                    "id" => $usr->id,
                    "nombre" => $usr->nombre,
                    "email" => $usr->email,
                    "tipo" => $usr->tipo
                );

                $jwt = JWT::encode($payload, KEY);
                $resp->access_token = $jwt;
            } else
                throw new Exception("Usuario o contraseña inexistente. Por favor revise los datos.");
        } catch (\Throwable $th) {
            $resp->message = $th->getMessage();
        }

        $response->getBody()->write(json_encode($resp));
        return $response;
    }


    private function userIsRegistered($nombre, $password)
    {
        $user = Usuario::where('nombre', $nombre)->get();
        $resp = null;
        if ($user) {
            foreach ($user as $key => $value) {
                # code...
                if ($password==$value->password) {
                    $resp = $value;
                }
            }
        }
        return $resp;
    }

    public function typeUser($id)
    {
        return Usuario::find($id)->type_user;
    }
}
